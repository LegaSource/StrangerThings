# Stranger Things
This mod introduces the Upside Down dimension and new enemies, bringing a new layer of tension to exploration and survival.

# The Upside Down
<details>
<summary>Description</summary>

### Access
Players can enter the Upside Down through portals that appear during the day or with the Demogorgon’s arrival.

### Environment
Crossing over dramatically alters the world:
- A blue mist affects the atmosphere.
- All lights instantly shut off, including inside the ship.
- The ship becomes fully disabled (no interactions or functionality).
- Outside the dungeon, a red thunderstorm rages permanently (functions like Stormy).

### Audio
- Players inside the Upside Down can hear players in the normal world, but with reduced volume.
- Players in the normal world cannot hear anyone inside the Upside Down.

### Visibility Rules
Players, monsters, items and configurable game objects are only visible if the player is in the same dimension.
- What exists in one world may be invisible in the other
- …until you cross over.
</details>

# Enemies
<details>
<summary>Description</summary>

All enemies are part of the Hive-Mind ecosystem.

## Demogorgon
<details>
<summary>Description</summary>

The iconic predator hunts players across worlds using portals and teleportation.

### Behavior in the Normal World
When the Demogorgon is in the main dimension:
- Invulnerable in this dimension.
- Wanders and stalks the map.
- If a player gets too close to a portal, the Demogorgon may detect and instantly teleport onto them
	- Teleport has a 1-minute cooldown.
	- After teleporting, it enters a 30-second chase, ignoring distance.

#### Chase Mechanics
- Melee strike when colliding with the player.
- Dash attack every 10 seconds:
	- Grabs the player on hit.
	- The dash can break doors, launching them as projectiles.
	- Players hit by a thrown door take light damage.

#### Dimensional Execution
If the Demogorgon grabs a player:
- The Demogorgon carries them to a nearby portal,
- Throws them into the Upside Down,
- And follows immediately afterward.

### Behavior in the Upside Down
- Becomes vulnerable and can be damaged normally.
- Dash no longer grabs, but deals heavy damage.
</details>

## Crustopikan Larvae
<details>
<summary>Description</summary>

A fast, ambushing creature that emerges from the ground.
- Spawns outdoors only.
- When spotting a player, it roars, then burrows underground.
- Burrows toward the player, emerging at close range to dash at them.
- Can also deliver light melee attacks.
</details>

## Crustopikan
<details>
<summary>Description</summary>

A slow but devastating Hive-Mind commander that summons allies and controls battle flow.
- Spawns outdoors only.
- When detecting a player, it emits a roar that alerts all nearby Hive-Mind creatures, who immediately rush toward it.
- If no creature responds, the Crustopikan pounds the ground, spawning two Crustopikan Larvae instead.
- Once its allies gather, it roars again to order them to attack the player.

### Behavior in Combat
- Moves slowly but is extremely dangerous.
- During a chase:
	- Can pull a rock from the ground and throw it at the player.
		- If the rock hits the ground, it may spawn a Crustopikan Larvae (up to 3 total across all abilities).
	- Has a one-shot melee attack if the player gets too close.
	
### Vulnerability
- The Crustopikan is immune to direct attacks.
- It can only be defeated through the Hive-Mind system (details below).
</details>
</details>

# Hive-Mind System
<details>
<summary>Description</summary>

## Hive-Mind Reactions
- When any Hive-Mind creature is attacked, all other connected creatures are stunned, interrupting their actions.
	- This can cancel aggressive moves (dash, throw, ...).

## Linked Damage
- If a Crustopikan is near a Hive-Mind creature that is attacked, the Crustopikan takes damage on behalf of the Hive-Mind.
- This is the only way to kill a Crustopikan.
</details>

# More informations
For any feedback/suggestions or questions, you can reach me on the 'Lethal Company Modding' Discord server (https://discord.gg/9rZjs3qZ) under the same name (username lega2039) or the Stranger Things thread.<br>
DMs are welcome.

# Attributions